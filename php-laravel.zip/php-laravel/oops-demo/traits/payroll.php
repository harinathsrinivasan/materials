<?php
trait PayrollTrait{
    public function calculateIncentive($percentage,$salary)
    {
        return $salary*$percentage;
    }

}
?>