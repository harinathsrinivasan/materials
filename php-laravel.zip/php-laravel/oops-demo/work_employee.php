<?php
use personmgmt as p;
use personmgmt\Employee;

class ContractEmployee extends Employee
{
    function demo(){
        parent::show();
    }
}
?>