<?php
namespace personmgmt;
include_once('./traits/payroll.php');
use \DateTime;
use \PayrollTrait ;

class Person{
    /**
     * public can be accessed by any1 ^default^
     * private cannot be accessed out side
     * protected can be accessed by direct inherited class
     */
    //data filed should be private preventing access from outside
    private $name;
    private $age;
    private $gender;
    private $dob;
    //By default all classes will have no argument constructor

    /**
     * Getter use to fetch the field/property data from a object
     * Setter use to set the value to the field/property data to a object
     */
    function __construct($name,$gender,$dob)
    {
        $this->name=$name;
        $this->gender=$gender;
        $this->dob=$dob;
    }
    function getName()
    {
        return $this->name;
    }

    function setName($name)
    {
        $this->name=$name;
    }
    
    function getAge()
    {
        return $this->age;
    }



    function getGender()
    {
        return $this->gender;

    }

    function setGender($gender)
    {
        $this->gender=$gender;
    }
    function getDob()
    {
        return $this->dob;
    }


    function calculate_age(){
      
        $dateInterval=date_diff(new DateTime(date("Y-m-d")),$this->dob);
        print_r($dateInterval);
        $this->age=$dateInterval->y;
        return $dateInterval->y;
    }
    function show(){
        echo "calling  parent";
        }
    function __destruct()
    {
        echo "destructor is called";
     $this->name=null;
     $this->age=null;
     $this->gender=null;   
    }
    static function name_comparator_asc($obj,$other)
    {
        $val=0;
        if($obj->name==$other->name)
        {
            $val=0;
        }
        $val=($obj->name<$other->name)?-1:1;
        
        return $val;
    }
    static function dob_comparator_asc($obj,$other)
    {
        $val=0;
        if($obj->dob==$other->dob)
        {
            $val=0;
        }
        $val=($obj->dob<$other->dob)?-1:1;
        
        return $val;
    }
    static function dob_comparator_desc($obj,$other)
    {
        $val=0;
        if($obj->dob==$other->dob)
        {
            $val=0;
        }
        $val=($obj->dob>$other->dob)?-1:1;
        
        return $val;
    }
}

//Instantiate object with default constructor

// $hari=new Person();
// $hari->setName("Harinath");
// $hari->setAge(31);
// $hari->setGender("Male");
// // print_r($hari);
// echo "name:".$hari->getName()."age:".$hari->getAge()."Gender".$hari->getGender().PHP_EOL;
// echo "ABove used getters and Setters";

// $hari=new Person("Harinath","Male",date_create("1990-12-21"));
// echo"date_difference return as"."<BR>";
// print_r($hari->calculate_age());
// echo "<BR>";
// echo "name:".$hari->getName().PHP_EOL."age:".$hari->getAge().PHP_EOL."Gender".$hari->getGender()."Age:".$hari->calculate_age().PHP_EOL;
// #destructing using null or dereferring
// $hari=null;
// echo "name:".$hari->getName().PHP_EOL."age:".$hari->getAge().PHP_EOL."Gender".$hari->getGender().PHP_EOL;
//#destructing using unset
// unset($hari);
// echo "name:".$hari->getName().PHP_EOL."age:".$hari->getAge().PHP_EOL."Gender".$hari->getGender().PHP_EOL;
#by default php auto call all __destruct()

class Employee extends Person{
private $empid;
private $salary;
private $designation;
private $department;
private static $employeeCount=0; 
function getEmpId()
{
    return $this->empid;
}
function showPerson()
{
    parent::show();//::Scope resoultion operator
}
function setEmpId($empId)
{
    return $this->empid=$empId;
}

function getSalary()
{
    return $this->salary;
}

function setSalary($salary)
{
    return $this->salary=$salary;
}
function getDesignation()
{
    return $this->designation;
}

function setDesignation($designation)
{
    return $this->designation=$designation;
}
function getDepartment()
{
    return $this->department;
}

function setDepartment($department)
{
    return $this->department=$department;
}
 

function show(){
    echo "calling  child";
    }

    /**
     * $this is for current instance
     * Self is for current class
     */
    static function addCount()
    {
        self::$employeeCount++;
    }
    static function  getCurrentEmployeeCount()
    {
        return self::$employeeCount;
    }
    
    
}

$hari=new Person("Harinath","Male",date_create("1990-12-21"));
$otherHari=new Person("Harinath","Male",date_create("1990-12-21"));
$manoj=new  Person("Manoj","Male","12-06-1997");
$prasanth=new  Person("Prasanth","Male","14-07-1997");
// $manoj->show();
// $manoj->showPerson();//accessing parent class
Employee::addCount();
echo ($hari!=$manoj)?"TRUE":"FALSE";
$persons=array($manoj,$hari,$prasanth);
usort($persons,array("personmgmt\Person","dob_comparator_desc"));
//print_r($persons);

class ContractEmployee extends Employee
{
    use PayrollTrait{
        calculateIncentive as public;
    }


   function getIncentive(){
        return $this->incentive;
   }
}
 $cemp=new ContractEmployee("Harinath","Male",date_create("1990-12-21"));
echo $cemp->calculateIncentive(15000,0.083);

//Sorting by name

/**=== equality operator for same instance
 * ==equality operator for different instance
 */


// $prasanth=new  Employee("Prasanth","Male","14-07-1997");
// Employee::addCount();
// echo "<BR>";
// echo "Manoj";
// echo "<BR>";
// print_r($manoj);
// echo "<BR>";
// echo "Prasanth";
// echo "<BR>";
// print_r($prasanth);
// echo "<BR>";
// echo Employee::getCurrentEmployeeCount();
// echo "<BR>";

/**
 * interface promotes lose coupling
 */

?>

