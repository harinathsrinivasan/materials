
    <div class= "container">
    <table  class="table table-striped table-hover">
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Price</th>
            <th>Category</th>
        </tr> 
        <?php
        require_once('D:/xampp/htdocs/CRUD/template/actions.php');
        include_once('D:/xampp/htdocs/CRUD/repo/repo.php');
       //global $products;
        foreach (getAllProducts() as &$product): ?>
        <tr>
            <td><?php echo $product['id'] ?></td>
            <td><?php echo $product['name'] ?></td>
            <td><?php echo $product['price'] ?></td>
            <td><?php echo $product['category'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    </div>
