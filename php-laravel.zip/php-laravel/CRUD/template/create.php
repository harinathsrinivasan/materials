<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Add Product</title>
</head>

<body>
    <h2 class=text-center> Add Products</h2>
    <div style="width: 60%; margin : auto;">
        <form action="actions.php" method="post">
            <div class="mb-3">
                <label class="form-label">ID</label>
                <input type="text" class="form-control" name="id">
            </div>
            <div class="mb-3">
                <label class="form-label">Name</label>
                <input type="text" class="form-control" name="name">
            </div>
            <div class="mb-3">
                <label class="form-label">Price</label>
                <input type="text" class="form-control" name="price">
            </div>
            <div class="mb-3">
                <label class="form-label">Category</label>
                <input type="text" class="form-control" name="category">
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
    <br />
    <br />

    <div style="width: 60%; margin : auto;">
        <h2>Search Product by Name</h2><br/>
       <form action = "actions.php" method = "get">
            <label class="form-label"><b>Name :</b> &nbsp;</label>
            <input type="text" class="form-control-sm" name="search" />
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
    </div>
    <br/><br/>
     <div style="width: 60%; margin : auto;">
        <h2>Delete Product by Name</h2><br/>
       <form action = "actions.php" method = "get">
            <label class="form-label"><b>ID :</b> &nbsp;</label>
            <input type="number" class="form-control-sm" name="delete" />
            <button type="submit" class="btn btn-primary">Delete</button>
        </form>
    </div>
</body>

</html>