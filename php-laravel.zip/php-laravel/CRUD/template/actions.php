<?php

global $products;
include 'D:/xampp/htdocs/CRUD/repo/repo.php';

$id = $_POST["id"];
$name =  $_POST["name"];
$price =  $_POST["price"];
$category =  $_POST["category"];


if($name == null  || $price == null  || $category == null)
{
    echo 'All Fields are required.';
}
else
{
$data = array(
    "id" =>  $id,
     "name" => $name,
      "price" => $price,
       "category" => $category);

print_r(createProduct($data));
}

echo '<br/><br/>';

// $name = $_GET["search"];

// print_r(SearchByName($_GET["search"]));
// print_r($resultData);

// echo '<br/><br/>';

// $id = $GET["delete"];

// print_r(deleteProduct($id));
?>

