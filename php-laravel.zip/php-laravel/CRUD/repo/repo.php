<?php

//error_reporting(E_ERROR);

    static $products = array(
        1 => array (
            "id"=> 1,
            "name" => "Iphone",
            "price" => 50000,
           "category" => "mobile"
        ),

        2 => array (
            "id"=> 2,
            "name" => "rs200",
            "price" => 20000,
            "category" => "bike"
        ),
        3 => array (
            "id"=> 3,
            "name" => "bmw",
            "price" => 95000,
            "category" => "car"
        )
    );




    function addProduct($id,$name,$price,$category)
    {
        global $products;
        $array_data = array("id"=> $id, "name"=>$name, "price" => $price, "category"=> $category);
        $GLOBALS['products'][$array_data["id"]]=$array_data;
    }
    addProduct(4,"manoj",4000,"human");

    function createProduct(&$product)
    {
        
         addProduct($product["id"],$product["name"],$product["price"],$product["category"]);

        print_r($product);
        echo "<br>";
        echo 'product added successfully';
        print_r($GLOBALS["products"]);
    }
    $tes_obj=array("id"=> 11, "name"=>"testObj", "price" => 21000, "category"=> "test");
     function updateProduct($product)
    {
    global $products;

    if($products[$product["id"]] == null)
    {
        echo 'item doesnt exist';
    }
    else
    {
        $products[$product["id"]] = $product;
    }
     }
    $update_data = array("id"=> 2, "name"=>"villa", "price" => 250000, "category"=> "mansion");
  //  updateProduct($update_data);


    function deleteProduct($id)
    {
     global $products;
    if($products["id"] == null)
    {
        echo 'id doesnt exist';
    }
    else
    {
      unset($products[$id]);
      echo 'id deleted successflly';
    }
    }
   //deleteProduct(6);


    function SearchByName($name)
    {
        global $products;
        $resultData =  array();
        foreach($products as $key => $value)
        {
            if($value["name"] == $name)
            {
                array_push($resultData, $value);
            }
        }
        return $resultData;
    }

    function getAllProducts()
    {
     global $products;
     return $products;
    }

?>

