<?php
include('repo.php');
print_r(getAllProducts());
?>