<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



class Service
{
    //
    public $val=50;
}

Route::get('/', function (Service $service) {
   return view('welcome');
});
Route::get('/product',[ProductController::class,'index']);
Route::get('/product/store',[ProductController::class,'store'])->name('product.store');
//Reource Route mapping -->rest resources
Route::resource('products', ProductController::class);

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/welcome_page', function () {
    return file_get_contents("../resources/views/custom_welcome.php");
});
Route::get('/welcome_page/{lang}', function ($lang) {
    if ($lang=="EN") {
        return file_get_contents("../resources/views/custom_welcome_EN.php");
    }
    if ($lang=="TA") {
        return file_get_contents("../resources/views/custom_welcome_TA.php");
    }
    if ($lang=="TE") {
        return file_get_contents("../resources/views/custom_welcome_TE.php");
    }

});

Route::middleware(['basicAuth'])->group(function(){
    Route::get('/product',[ProductController::class,'index']);
    Route::get('/product/store',[ProductController::class,'store'])->name('product.store');
});

