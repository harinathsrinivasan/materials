<html>
<body>
Welcome to my custome laravel home page.
</body>
</html>
