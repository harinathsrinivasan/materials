<?php
session_start();
if (isset($_SESSION['username'])) {
    // echo '&nbsp; <h2> Welcome '.$_SESSION['username'].'</h2>';
} else {
    header("Location: login.php");
}
?>

<?php
include_once("header.php");

include("dbCon.php");

include_once("repo.php"); ?>
<?php
$id =   $_GET['rejectid'];
//Database Connection
if (isset($_POST['submit'])) {


    $cat = $_POST['category'];
    $sub = $_POST['subject'];
    $rejstatus = $_POST['status'];
    $date =  date('Y-m-d');
    $reason = $_POST['reason'];


    //Query for data updation
   

    if ($query) {
        UpdateTicket($rejstatus, $id);
        echo "<script > document.location ='ticket_status.php'; </script>";
    } else {
        echo "<script>alert('Something Went Wrong. Please try again');</script>";
    }
}
?>

<div class="container" style="position:absolute;top:20%; left:33%">
    <div class="row">
        <div class="col-sm-8">
            <form method="POST" style="width: 80%;box-shadow:2px 2px 12px;padding:20px">
                <?php

                $pid = $_GET['rejectid'];
                $ret = mysqli_query($con, "select * from getcenterDetails where id ='$pid'");
                while ($row = mysqli_fetch_array($ret)) {
                ?>

                    <h2 class="hint-text" style="text-align:center">Update your Reason.</h2>
                    <br>

                    <div class="form-group">
                        <input type="text" class="form-control" name="schedule_id" value="<?php echo $row['schedule_id'];  ?>">
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control" name="center_id" value="<?php echo $row['center_id']; ?>">
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control" name="fdate" value="<?php echo $row['from_date']; ?>">
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control" name="tdate" value="<?php echo $row['to_date']; ?>">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="status" value="<?php echo $row['status']; ?>">
                    </div>
                    <div class="form-group">
                        <textarea type="text" class="form-control" name="reason" placeholder="reason"></textarea>
                    </div>


                <?php
                } ?>
                <div class="form-group">
                    <button type="submit" class="btn btn-success btn-lg btn-block" name="submit">Update</button>
                </div>
            </form>
        </div>
    </div>