
<?php
include_once("repo.php");


//Code for deletion
if (isset($_GET['openid'])) {
    $id = intval($_GET['openid']);




    $status = 'open';

    $result = UpdateCenter($status, $id);
    $query = mysqli_query($con, $result);

    echo "<script>window.location.href = 'employee_dashboard.php'</script>";
}
