
<?php
include_once("repo.php");


//Code for deletion
if (isset($_GET['closeid'])) {
    $id = intval($_GET['closeid']);


    

    $status = 'close';

    $result = UpdateCenter($status, $id);
    $query = mysqli_query($con, $result);

        echo "<script>window.location.href = 'employee_dashboard.php'</script>";
}
