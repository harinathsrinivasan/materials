<?php include_once("header.php");
include_once("dbCon.php");
include_once("repo.php");

?>

<?php
session_start();

if (isset($_SESSION['username'])) {
    // echo '&nbsp; <h2> Welcome ' . $_SESSION['username'] . '</h2>';
} else {
    header("Location: login.php");
}

?>
<div style="width: 80em; margin: auto;">
    <h2 style="text-align: center;">Vaccination Centers </h2>
    <div class="tb_search" style="width:28%; float:right;">

        <input type="text" id="search_input_all" onkeyup="FilterkeyWord_all_table()" placeholder="Search.." class="form-control">
    </div>
    <br>
    <table class="table responsive-table  table-striped" id="table-id">
        <br>
        <thead>
            <tr>
                <th scope="col">Schedule Id</th>
                <th scope="col">Center Id</th>
                <th scope=" col">From Date</th>
                <th scope=" col">To Date</th>
                <th scope="col"> status</th>
                <th scope="col"> Action</th>
            </tr>
        </thead>

        <tbody>
            <?php $result =  getcenterDetails(); ?>
            <?php while ($row = mysqli_fetch_array($result)) { ?>
                <tr>
                    <td> <?php echo $row['schedule_id'] ?> </td>
                    <td> <?php echo $row['center_id'] ?> </td>
                    <td> <?php echo $row['from_date'] ?> </td>
                    <td> <?php echo $row['to_date'] ?> </td>
                    <td> <?php echo $row['status'] ?> </td>
                    <td>
                        <a href="../evms/open.php?openid=<?php echo $row['center_id'] ?>" class="btn btn-success">Open</a> &nbsp;
                        <a href="../evms/close.php?closeid=<?php echo $row['center_id'] ?>" class="btn btn-info">Close</a> &nbsp;
                        <a href="../evms/reject1.php?rejectid=<?php echo $row['center_id'] ?>" class="btn btn-danger">Reject</a> &nbsp;
                    </td>


                </tr>
            <?php }  ?>
        </tbody>
    </table>

    <div style="width: 25%; margin :auto"> 
        <?php include_once("footer.php") ?>
    </div>
</div>




<script>
    // All Table search script
    function FilterkeyWord_all_table() {

        // Count td if you want to search on all table instead of specific column

        var count = $('.table').children('tbody').children('tr:first-child').children('td').length;

        // Declare variables
        var input, filter, table, tr, td, i;
        input = document.getElementById("search_input_all");
        var input_value = document.getElementById("search_input_all").value;
        filter = input.value.toLowerCase();
        if (input_value != '') {
            table = document.getElementById("table-id");
            tr = table.getElementsByTagName("tr");

            // Loop through all table rows, and hide those who don't match the search query
            for (i = 1; i < tr.length; i++) {

                var flag = 0;

                for (j = 0; j < count; j++) {
                    td = tr[i].getElementsByTagName("td")[j];
                    if (td) {

                        var td_text = td.innerHTML;
                        if (td.innerHTML.toLowerCase().indexOf(filter) > -1) {
                            // var td_text = td.innerHTML;  
                            //td.innerHTML = 'shaban';
                            flag = 1;
                        } else {
                            //DO NOTHING
                        }
                    }
                }
                if (flag == 1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        } else {
            //RESET TABLE
            $('#maxRows').trigger('change');
        }
    }
</script>