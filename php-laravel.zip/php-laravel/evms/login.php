

<?php
session_start();
if(isset($_POST['submitbtn']))
{    
  $username = $_POST['username'];
  $password = $_POST['password'];

  $users = array("admin"=>"admin","user"=>"user");
  

    foreach ($users as $key => $value) {
    $login = ($key === $username && $value === $password) ? true : false;
    if($login) break;
    }
    
    if($login)
    {
        $_SESSION['username'] = $_POST['username'];
        echo   $_SESSION['username']." successfully logged";

          if ($_SESSION['username'] == 'admin')
          header("Location: employee_dashboard.php");
          elseif ($_SESSION['username'] == 'user')
           header("Location: portal.php");

         ?>

        <?php
    }
    else
    {
            echo "Username and password is not valid";?>
            <script>setTimeout(
                function(){
                window.location = "http://localhost:8080/evms/login.php";}, 1000);
            </script>
            <?php
    }
}
  $userErr = $pwdErr = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" )
{
    
    $username =  check_input($_POST["username"]);
    if (empty($username) OR !preg_match("/^[A-Za-z]*$/",$username) OR (strlen($username) < 3)) 
    {
      $userErr = "<p>* UserName field is required and must be  characters.</p>";
    }

    $password =  check_input($_POST["password"]);
    if (empty($password) OR !preg_match("/^[a-zA-Z0-9]*$/",$password) OR (strlen($password) < 3)) 
    {
      $pwdErr = "<p>* Password field is required and must be  characters.</p>";
    }

}
function check_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
</head>
<body style="background-image: url('https://external-preview.redd.it/DUMkFZ-8j0SB4A2wqisQLnGHwSYo6Q27PiPo2nC74tc.jpg?auto=webp&s=9a809ace563c5596c565338814db005d102d95e1');
  background-repeat: no-repeat;background-attachment: fixed ;background-size: cover; opacity:0.9;">
    <div style=" width:50% ; margin :50px  auto; box-shadow: 2px 2px 12px; background-color: aliceblue;opacity :0.9;border-radius:5px;">
    <div style = "width: 100%; margin : auto;padding :20px; ">
    <div class ="row">
  

      <div class="col">
        <h2 style = "text-align : center; text-decoration: underline">Login Details</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" class="form-control" name="username">
                  <span class="error"  style= "color:red;"> <?php echo $userErr;?></span> 
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="text" class="form-control" name="password">
                 <span class="error"  style= "color:red;"> <?php echo $pwdErr;?></span>
            </div>
            <div>
                <button   name = "submitbtn" class = "btn btn-success"> Submit</button>
            </div>
        </form>
     </div>
</div>
    </div>
    
   
</body>
</html>