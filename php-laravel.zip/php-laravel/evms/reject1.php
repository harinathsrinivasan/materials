
<?php
include_once("repo.php");
include_once("dbCon.php");

//Code for deletion
if (isset($_GET['rejectid'])) {
    $id = intval($_GET['rejectid']);
    $status = "rejected";

    $result =    DeleteCenter($_GET['rejectid']);

    $to_email = 'demohtc88@gmail.com';
    $subject = "Appointment rejected  ";
    $body = "<HTML>
        <Body>
        <h3>Thanks for scheduling vaccination but suddenly the center has closed and will inform you if center has open</h3>
    
        <br>
         <p>Thankyou have a nice day.</p
        
        
        </Body>
        </HTML>";
    $headers = "From: sender email" . "\r\n" . "Content-type: text/html; charset=iso-8859-1</iso-8859-1> " . "\r\n";


    if (mail($to_email, $subject, $body, $headers)) {
        // echo "Email successfully sent to $to_email...";
    }

   
    echo "<script>window.location.href = 'employee_dashboard.php'</script>";
}
