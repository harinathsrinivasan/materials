<?php include_once("header.php");
include_once("dbCon.php");
include_once("repo.php");

?>

<?php
session_start();

if (isset($_SESSION['username'])) {
    // echo '&nbsp; <h2> Welcome ' . $_SESSION['username'] . '</h2>';
} else {
    header("Location: login.php");
}

?>
<div style="width: 50em; margin: auto;">
    <h2 style="text-align: center;">Vaccination Centers </h2>
    <div class="tb_search" style="width:28%; float:right;">

        <input type="text" id="search_input_all" onkeyup="FilterkeyWord_all_table()" placeholder="Search.." class="form-control">
    </div>
    <br>
    <table class="table responsive-table  table-striped" id="table-id">
        <br>
        <thead>
            <tr>
                <th scope="col">Center Id</th>
                <th scope=" col">Center Name</th>
                <th scope=" col">Address</th>
                <th scope="col"> Pincode</th>
                <th scope="col">isOpen</th>
                <th scope="col">Capacity</th>
                <th scope="col">Check</th>

            </tr>
        </thead>

        <tbody>
            <?php $result =  getvaccination_centers(); ?>
            <?php while ($row = mysqli_fetch_array($result)) { ?>
                <tr>
                    <td> <?php echo $row['center_id'] ?> </td>
                    <td> <?php echo $row['center_name'] ?> </td>
                    <td> <?php echo $row['address'] ?> </td>
                    <td> <?php echo $row['pincode'] ?> </td>
                    <td> <?php echo $row['isOpen'] ?> </td>
                    <td> <?php echo $row['capacity'] ?> </td>
                    <?php if ($_SESSION['username'] == 'user') { ?>
                        <td>
                            <a href="../evms/Reserve.php?id=<?php echo $row['center_id'] ?>" class="btn btn-success">Select</a> &nbsp;
                        </td>
                    <?php } ?>


                </tr>
            <?php  } ?>
        </tbody>

    </table>

</div>
<div style="width: 25%;  position:absolute;bottom:0;left:35%">
    <?php include_once("footer.php") ?>
</div>
<script>
    // All Table search script
    function FilterkeyWord_all_table() {

        // Count td if you want to search on all table instead of specific column

        var count = $('.table').children('tbody').children('tr:first-child').children('td').length;

        // Declare variables
        var input, filter, table, tr, td, i;
        input = document.getElementById("search_input_all");
        var input_value = document.getElementById("search_input_all").value;
        filter = input.value.toLowerCase();
        if (input_value != '') {
            table = document.getElementById("table-id");
            tr = table.getElementsByTagName("tr");

            // Loop through all table rows, and hide those who don't match the search query
            for (i = 1; i < tr.length; i++) {

                var flag = 0;

                for (j = 0; j < count; j++) {
                    td = tr[i].getElementsByTagName("td")[j];
                    if (td) {

                        var td_text = td.innerHTML;
                        if (td.innerHTML.toLowerCase().indexOf(filter) > -1) {
                            // var td_text = td.innerHTML;  
                            //td.innerHTML = 'shaban';
                            flag = 1;
                        } else {
                            //DO NOTHING
                        }
                    }
                }
                if (flag == 1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        } else {
            //RESET TABLE
            $('#maxRows').trigger('change');
        }
    }
</script>