<?php include_once("header.php");
include_once("repo.php");

session_start();

if (isset($_SESSION['username'])) {
    // echo '&nbsp; <h2> Welcome ' . $_SESSION['username'] . '</h2>';
} else {
    header("Location: login.php");
}
?>
<?php

$date_error = '';

$data = $_GET['id'];
if (isset($_POST["submit"])) {
    
    $date1 = new DateTime();
    $date2 =  new DateTime($_POST["date"]);
    $date =  date($_POST["date"]);
    if ($date2 > $date1) {

        $result =  getPerson($data);

        if ($result) {
            while ($row = mysqli_fetch_array($result)) {

                $id = $row['center_id'];
                $status  = $row['isOpen'];
            }

            $result =   createSchedule($id, $date, $date, $status);
            $query = mysqli_query($con, $result);
            $to_email = 'demohtc88@gmail.com';
            $subject = " Vachine Scheduled Successfully ";
            $body = "<HTML>
        <Body>
        <h3>Thanks for scheduling vaccination</h3>
      
        <p>
         <h3>Dear $fname &nbsp; $lname &nbsp; your have scheduled  for vaccination with refernce aadhar number &nbsp; $aadhar &nbsp;
         on $date  &nbsp; with center id $id 
         </h3><br>
         <p>Thankyou have a nice day.</p
        
        
        </Body>
        </HTML>";
            $headers = "From: sender email" . "\r\n" . "Content-type: text/html; charset=iso-8859-1</iso-8859-1> " . "\r\n";


            if (mail($to_email, $subject, $body, $headers)) {
                // echo "Email successfully sent to $to_email...";
            }

           
            header("Location: schedule.php");
        }
    } else {
        $date_error = "<p> select future date only</p>";
    }
}

?>





<div class="jumbotron jumbotron-fluid" style="width: 400px;margin:auto">
    <div class="container">
        <h1 style="text-align: center;text-decoration: underline;">Reserve Date</h1>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" style="width: 200px;margin:auto">
            <div class="form-group">
                <label for="exampleInputEmail1">Date</label>
                <input type="date" class="form-control " name="date">
                <span class="error" style="color:red"><?php echo $date_error ?></span>
            </div>
            <input type="submit" class="btn btn-primary" name="submit"></button>
        </form>
    </div>
</div>
<div style="width: 25%;  position:absolute;bottom:0;left:35%">
    <?php include_once("footer.php") ?>
</div>