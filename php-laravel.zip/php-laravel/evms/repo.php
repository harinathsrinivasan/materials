<?php
include_once("dbCon.php");

function createUser($fname, $mname, $lname, $aadhar, $email, $phoneNo, $address, $pincode)
{
    global $con;
    $status = false;
    $query = "INSERT INTO `person`(`first_name`, `middle_name`, `last_name`, `social_identification_no`, `email`, `phone_no`, `address`, `pincode`)
    values(?,?,?,?,?,?,?,?)";

    $statement = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($statement, 'ssssssss',  $fname, $mname, $lname, $aadhar, $email, $phoneNo, $address, $pincode);
    $exc_status = mysqli_stmt_execute($statement);
    if ($exc_status) {
        $var = mysqli_affected_rows($con);
        if ($var == 1) {
            $status = true;
        }
    }
    return $status;
}




function createSchedule($centerid, $from_date, $to_date, $Status)
{
    global $con;
    $status = false;
    $query = "INSERT INTO `center_schedule`( `center_id`, `from_date`, `to_date`, `status`) VALUES (?,?,?,?)";

    $statement = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($statement, 'isss',  $centerid,$from_date,$to_date,$Status);
    $exc_status = mysqli_stmt_execute($statement);
    if ($exc_status) {
        $var = mysqli_affected_rows($con);
        if ($var == 1) {
            $status = true;
        }
    }
    return $status;
}

function getvaccination_centers()
{
    global $con;

    $query = "SELECT * FROM vaccination_center"
;

    $result1 = mysqli_query($con, $query);

    return $result1;
}

function getcenterDetails()
{
    global $con;

    $query = "SELECT * FROM `center_schedule`";

    $result = mysqli_query($con, $query);

    return $result;
}

function getPerson($id)
{
    global $con;

    $query = "SELECT * FROM  vaccination_center where center_id like   '%$id%' ";

    $result1 = mysqli_query($con, $query);

    return $result1;
}

getPerson(102);



function UpdateReservation($center_id, $res_date, $person_id)
{

    global $con;
    $status = false;
    $query = "INSERT INTO `person_center_reservation`( `center_id`, `reservation_date`, `person_id`) VALUES (?,?,?)";
    //preparing the statement
    $statement = mysqli_prepare($con, $query); //returns mysqli_statement
    mysqli_stmt_bind_param($statement, 'isi',  $center_id,$res_date, $person_id); //binding parameter to the statement
    //executing the statement
    $exc_status = mysqli_stmt_execute($statement); //return  boolean
    if ($exc_status) {
        $var = mysqli_affected_rows($con); //Returns a resultset or FALSE on failure.
        //For inserting result will return true.
        if ($var == 1) {
            $status = true;
        }
    }

    return $status;
}
function UpdateCenter($is_open,$center_id)
{

    global $con;
    $status = false;
    $query = "UPDATE `vaccination_center` SET `isOpen`= ? WHERE center_id = ?";
    //preparing the statement
    $statement = mysqli_prepare($con, $query); //returns mysqli_statement
    mysqli_stmt_bind_param($statement, 'si', $is_open, $center_id); //binding parameter to the statement
    //executing the statement
    $exc_status = mysqli_stmt_execute($statement); //return  boolean
    if ($exc_status) {
        $var = mysqli_affected_rows($con); //Returns a resultset or FALSE on failure.
        //For inserting result will return true.
        if ($var == 1) {
            $status = true;
        }
    }

    return $status;
}

function DeleteCenter($id)
{

    global $con;
    $status = false;
    $query = "DELETE FROM `center_schedule` WHERE `center_schedule`.`center_id` = ? ";
    //preparing the statement
    $statement = mysqli_prepare($con, $query); //returns mysqli_statement
    mysqli_stmt_bind_param($statement, 'i', $id); //binding parameter to the statement
    //executing the statement
    $exc_status = mysqli_stmt_execute($statement); //return  boolean
    if ($exc_status) {
        $var = mysqli_affected_rows($con); //Returns a resultset or FALSE on failure.
        //For inserting result will return true.
        if ($var == 1) {
            $status = true;
        }
    }
    return $status;
}

?>