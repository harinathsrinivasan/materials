<?php 

include('../repository/db_repo_proc.php');
// $result=createUser("anvesh","anvesh@htcindia.com","+911234567896");

// if($result)
// {
// echo"data insertion is successfull";
// }
// else{
//     echo"data insertion failed.";
// }
// $result=createUser("MohanRaj","Mohanraj@htcindia.com","+911234567897");

// if($result)
// {
// echo"data insertion is successfull";
// }
// else{
//     echo"data insertion failed.";
// }
// $result=createUser("Mohan K","Mohan.k@htcindia.com","+911234567897");

// if($result)
// {
// echo"data insertion is successfull";
// }
// else{
//     echo"data insertion failed.";
// }

$result=getUsersByname("Mohan K");
if($result)
{
while($row=mysqli_fetch_assoc($result))
{
    echo "id:".$row["id"]."name:".$row["name"]."email".$row["email"]."phoneno".$row["phoneno"]."<br>";
}
}
else{
    echo "no records found";
}

?>