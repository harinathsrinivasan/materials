<?php
include('../config/db.php');
error_reporting(E_ERROR);
$connection=getConnection('Mysql');
print_r($connection);
if(!$connection)
{
    /** 
     * The die() is an inbuilt function in PHP.
     * It is used to print message and exit from the current php script
    */
    
    die('unable to connect to database'.mysqli_connect_error());
}
else
{
    echo 'connected successfully';
}
?>