<footer class="footer fixed-bottom footer-copyright">
&#169;
HTC global service 	&#174;
Chennai

</footer>