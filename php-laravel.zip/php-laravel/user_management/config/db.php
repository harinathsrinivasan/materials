<?php

function getConnection($databaseVendor)//FACTORY DESIGN PATTERN
{
    $con=null;
    switch(strtoupper($databaseVendor))
    {
        case "MYSQL":
        $mysql_servername = "localhost";
        $mysql_username = "root";
        $mysql_password = "123Welcome";
        $mysql_host="localhost";
        $db="usermgmt";
        /*
         *  mysqli_connect() returns mysqli type (variable)object or false  or null
         * 
         * */
        $con= mysqli_connect($mysql_host,$mysql_username,$mysql_password,$db);

        break;
    }
    return $con;

}
?>