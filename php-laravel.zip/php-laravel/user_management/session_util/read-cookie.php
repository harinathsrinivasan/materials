<?php
$_COOKIE["name"];//its super global predefined variable which is type is associative array
//delete cookie
unset($_COOKIE["LastVisitedTime1"]);
print_r($_COOKIE["LastVisitedTime1"]);
?>