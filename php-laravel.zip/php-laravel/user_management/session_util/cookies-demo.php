<?php

//creating or setting cookies via http header

header("Set-Cookie:name='CRUD DEMO';expires=0;path=/CRUD;domain=localhost");

//creating cookies with cookies method

setcookie("LastVisitedTime1",time(),time()+3600,"/","localhost");
echo "Creating  cookies";
?>