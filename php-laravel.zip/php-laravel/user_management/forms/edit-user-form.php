<?php
include_once('../repository/repo.php');
$users_arr=$GLOBALS['users'];
$id=$_GET["id"];
$user =$users_arr[$id] //$users[$id]
?>
<form  id="edit_user" action="../repository/update-user.php" method="post">
<Label>Name</Label>

<!-- Hidden Form Field-->
<input id="id" type="hidden" name="id" value=<?php echo$user["id"]?>>

<input id="name" type="text" name="name" value=<?php echo$user["name"]?>>
<Label>Email</Label>
<input id="name" type="email" name="email" value=<?php echo$user["email"]?>>
<Label>Phone No</Label>
<input id="name" name="phoneno"  type="text" value=<?php echo$user["phoneno"]?>>
<input id="updateBtn" type="submit" name="update" value="update">
</form>
