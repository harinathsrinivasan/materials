
<table>
<thead>
<tr>
<th>id</th>
<th>name</th>
<th>email</th>
<th>phone No</th>
<th colspan="3">actions</th>
<th>&nbsp;</th>
<th>&nbsp;</th>

</th>
</tr>
</thead>
<?php
include_once('../repository/repo.php');
global $users;

foreach($users as $user)
{

?>
<tr>
<td><?php echo $user["id"];?></td>
<td><?php echo $user["name"];?></td>
<td><?php echo $user["email"];?></td>
<td><?php echo $user["phoneno"];?></td>
<td><a href="edit-user-form.php?id=<?php echo $user["id"];?>"> Edit</a> </td>
<td><a href= "../repository/delete-user.php?id=<?php echo $user["id"];?>">Delete </a> </td>
</tr>
<?php
}
?>
</table>