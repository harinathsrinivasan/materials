<?php
include('../repository/repo.php');
$query_value_err;
$query;
/*
??coalesce is used to deal with null value it will
if the value it will replace with given value
<Variable need to be check>??"Value need to be displayed instead of null"
*/
//print_r($_GET["submit"]??"Form not yet submitted<br>");
//to check wether a variable is null or value is unset
if(isset($_GET["submit"]))
{
    $query=filter_input(INPUT_GET,"query",FILTER_SANITIZE_STRING);

if(ctype_alpha($query))
{
    print_r(search_user_by_name($query));
}
else{
    $query_value_err="should not contain symbol and numbers";
}
}
?>

<form name="search_form" method="get" action="search.php">
<label>Enter name to search </label>
<input type="textbox" name="query" placeholder="Enter the Name" value=<?php echo $query?>>
<?php if(isset($query_value_err))
{
    echo "<br>".$query_value_err."<br>";
}
?>
<input type="submit" value="search" name="submit">
</form>