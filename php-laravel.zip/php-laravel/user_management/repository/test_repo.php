<?php
//include --> will try to include the resources even its already included
//it will raise duplicate variable declaration,function declaration
include_once("repo.php");//check wether module is included if not it will include
$updated_users;
function testingCalls()
{
$result=createUser(array("id"=>101,"name"=>"test1","email"=>"harinath@htc.com","phoneno"=>1234567890),$GLOBALS['users']);
if($result)
{
    echo "added successfully";
}
testingCalls();
}
$pass_obj=$GLOBALS['users'];
echo count($pass_obj);
print_r(search_user_by_name("test",$GLOBALS['users']));
$GLOBALS['updated_users']=$pass_obj;
var_dump($pass_obj);
//include('get_test.php');
?>