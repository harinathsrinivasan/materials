<?php

error_reporting(E_ERROR);//it will not display warning it will display error message only
 static $users = array(
    1 => array("id"=>1,"name"=>"Harinath","email"=>"harinath@htc.com","phoneno"=>1234567890),
    2 => array("id"=>2,"name"=>"Ben","email"=>"ben@htc.com","phoneno"=>9876543210),
    3 => array("id"=>3,"name"=>"Tom","email"=>"tom@htc.com","phoneno"=>4567891230),
    4 => array("id"=>4,"name"=>"Jerry","email"=>"jerry@htc.com","phoneno"=>7894561230),
    5 => array("id"=>5,"name"=>"Scooby","email"=>"jerry@htc.com","phoneno"=>1472583690)
);
function createUser($user,&$arr_obj)
{

    $status=false;
    $isfound=false;
    //global $users;//if we want to access it as global 
    $id=$user["id"];
    $arr_obj[$id]=$user;
    //after data insertion checking the array data against passed data checking it contatins 
    //passed data as value
    foreach($arr_obj as $key=>$value)
    {
        if($value===$user) //=== identity operator
        {
            $isfound=true;
        }
    }
    var_dump($arr_obj);//provide the information about variablevar
    echo"printing current global variable";
    var_dump($GLOBALS['users']);

    if($isfound)
    {
        $status=true;
    }
    return $status;
}

function deleteUser($id)
{ $status=false;
    $isnotfound=false;
    global $users;
    unset($users[$id]);
    foreach($users as $key=>$value)
    {
        if($value["id"]!=$id) //=== identity operator
        {
            $isnotfound=true;
        }
    }
    if($isnotfound)
    {
        $status=true;
    }
    return $status;
}

function updateUser($user)
{
global $users;
if($users[$user["id"]]==null)
{
    echo"item doesnt exist";
}
else
{
    $users[$user["id"]]=$user;
    echo " value are updated successfully<br>";
}
}
/*
1.many user may have a same name in that scenario it going return more than one value
2.If we need return multiple value we need to use array.
3.in function control flow reaches return statement 
it will return to caller so we cant have multiple return statement
*/
function search_user_by_name($name,&$arrays)
{
    $isfound=false;
    $resultData=array();//intialize as the array
   // global $users;
    var_dump($arrays);
    foreach($arrays as $key=>$value)
    {
        if($value["name"]==$name)
        {
            $isfound=true;
            array_push($resultData,$value);
        }
    }

    if($isfound==false)
    {
        $resultData="Data not found";
    }

    return $resultData;
}

print_r(search_user_by_name("Jerry",$users));
?>
