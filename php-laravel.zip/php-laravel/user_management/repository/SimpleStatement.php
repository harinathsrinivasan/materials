<?php
include('../config/db.php');

$connection=getConnection("Mysql");

if($connection){
//Connection established successfully proceeding with query
//Select from table
//DQL
// $statement="SELECT id,name,email,phoneno FROM users"; //DQL
// $result=mysqli_query($connection,$statement);

// if(mysqli_num_rows($result)>0)
// {
// while($row=mysqli_fetch_assoc($result))
// {
//     echo "id:".$row["id"]."name:".$row["name"]."email".$row["email"]."phoneno".$row["phoneno"]."<br>";
// }

// while($row=mysqli_fetch_row($result))
// {
//     echo "id:".$row[0]."name:".$row[1]."phoneno".$row[3]."email".$row[2]."<br>";
// }
//}

//INserting into data
//DML
$statement="INSERT INTO users (name,email,phoneno)VALUES ('chinnaraju','chinnaraju@htcindia.com',1234587690)";
$result=mysqli_query($connection,$statement);
if(mysqli_affected_rows($connection)==1)
{
    echo "value inserted successfully";
}
else{
    echo "failed to save data";
}

$statement="INSERT INTO users (name,email,phoneno)VALUES ('durgaprasad','durgaprasad@htcindia.com',1234587691)";
$result=mysqli_query($connection,$statement);
if(mysqli_affected_rows($connection)==1)
{
    echo "value inserted successfully";
}
else{
    echo "failed to save data";
}
//update or delete we cant guarantee 
//how many rows are affected 
//unless we are using primary key column or unique columnn in where condition
// $statement="UPDATE users set name='arun' where mobileno=1234587690)";
// $result=mysqli_query($connection,$statement);
// if(mysqli_affected_rows($connection)>0)
// {
//     echo "value inserted successfully";
// }
// else{
//     echo "failed to save data";
// }
//DDL
$statement="CREATE table test_purpose(id int,name varchar(50))";
$result=mysqli_query($connection,$statement);
if($result)
{
    echo "Table created successfully";
}
else{
    echo "table creation failed";
}


}

//DDL statement.
/**
 * DDL statement or mostly not allowed for application developer 
 * its has  been handled DB team
 * its a one time action (while doing intial setup or application upgrades we will be using ddl statement)
 * 
 */



?>