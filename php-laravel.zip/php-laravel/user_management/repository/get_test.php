<?php
require("repo.php");
include_once('test_repo.php');
echo "From get_test.php".count($GLOBALS['users']);
print_r(search_user_by_name("test",$GLOBALS['users']));

var_dump($GLOBALS['users']);



?>