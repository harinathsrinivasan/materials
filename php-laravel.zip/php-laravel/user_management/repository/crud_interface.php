<?php
interface IUserRepo{
    function createUser($name,$email,$phone_no);
    function getAllUser();
    function getUsersByname($name);
    function searchUserByanyField();
    function getUserByemail($email);
    function updateUser($user);
    function updateUserEmailAddress($userId,$emailAddress);
    function deleteUserByid($user);
}

interface IJSONSerializable
{
    
}

?>