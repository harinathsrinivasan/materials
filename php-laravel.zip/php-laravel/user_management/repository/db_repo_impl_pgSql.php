<?php

/*Character	Description
i	corresponding variable has type integer
d	corresponding variable has type double
s	corresponding variable has type string
b	corresponding variable is a blob and will be sent in packets
*/
include_once('../config/db.php');
include_once('./crud_interface.php');
$connection =pg_connect("dbname=usrmgm");
class UserRepository implements IUserRepo
{
    public function createUser($name, $email, $phone_no)
    {
        /**
         * mysqli_prepare(mysqli $mysql, string $query)
         * input:-
         *  first parameter:-
         *      successful execution of mysqli_connect()(predefined method ) method
         *      which will return mysqli type variable.
         *
         *  second parameter:-
         *      Sql query
         *
         * output:-
         *
         * mysqli_stmt or false
         */
        global $connection;
        $status=false;
        $query="INSERT INTO users(name,email,phoneno) values($1,$2,$3)";
        //preparing the statement
    $statement=pg_prepare($connection, $query);//returns mysqli_statement
        //executing the statement
    $exc_status=pg_execute($connection,$statement,array($name,$email,$phone_no));//return  boolean
    if ($exc_status) {
        $var=pg_result($connection);//Returns a resultset or FALSE on failure.
        //For inserting result will return true.
        if ($var==1) {
            $status=true;
        }
    }
        return $status;
    }
    public function getUsersByname($name)
    {
        global $connection;
        $result=false;
        $query="SELECT id,name,email,phoneno FROM users WHERE  name=?";
        $statement=mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($statement, 's', $name);
        $exc_status=mysqli_stmt_execute($statement);

        if ($exc_status) {
            $result= mysqli_stmt_get_result($statement);//Returns a resultset or FALSE on failure.
        }
        return $result;
    }
    function getAllUser()
    {

    }
    function searchUserByanyField()
    {

    }
    function getUserByemail($email)
    {

    }
    function updateUser($user)
    {

    }
    function updateUserEmailAddress($userId,$emailAddress)
    {

    }
    function deleteUserByid($user)
    {

    }
}

?>