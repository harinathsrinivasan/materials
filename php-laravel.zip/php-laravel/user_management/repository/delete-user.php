<!--Use to handle http request like Applying filters,authentication,authorization-->

<?php
include_once("../repository/repo.php");
$id=$_GET["id"];
deleteUser($id);

var_dump($GLOBALS["users"]);
//include_once("../forms/users-table-view.php");
header("Location:.././index.php");

?>