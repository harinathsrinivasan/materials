<?php
$id=$_POST["id"];
$name=$_POST["name"];
$email=$_POST["email"];
$phoneNo=$_POST["phoneno"];
include_once("../repository/repo.php");

updateUser(array("id"=>$id,"name"=>$name,"email"=>$email,"phoneno"=>$phoneNo));

echo "updated values";

//Add search_user_by_id method in repo.php
print_r(search_user_by_name($name,$GLOBALS["users"]));

?>