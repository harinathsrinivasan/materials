<?php
//$bytes=readfile("../environment_setting.txt");//directly show the data in output screen ie
//echo $bytes;

$targetFile=fopen("../environment_setting.txt","r") or exit("File not found");
echo "Current Data";
while(!feof($targetFile))
{
    echo "<BR>";
    echo fgets($targetFile);
    echo"*";
}
/**
 * fgets() to read line by line
 * fgetc() to read char by char
 */

 //
 fclose($targetFile);

 $inputFile=fopen("../environment_setting.txt","r") or exit("File not found");
echo "Current Data";
$fileproperties=array();
while(!feof($inputFile))
{

    $fileproperties[]=fgets($inputFile);//loaded into memory

}

echo"In Memory Data"."<BR>";
var_dump($fileproperties);
/**
 * fgets() to read line by line
 * fgetc() to read char by char
 */

fclose($inputFile);
//Adding value to the array which contain file data.
$server= "Server=xampp/Tomcat".PHP_EOL;
array_splice($fileproperties,1,0,$server);
//unloading data into another file
 $outputFile=fopen("../environment_setting_updated.txt","x+") or exit("File not found");
 foreach ($fileproperties as $value) {
     fwrite($outputFile, $value);
 }
 fclose($outputFile);

 //Appending data into existing file
//  $targetFile=fopen("../environment_setting.txt","a") or exit("File not found");
// fwrite($targetFile,$server);
// fclose($targetFile);
echo "added Data";
$targetFile=fopen("../environment_setting.txt","r") or exit("File not found");
while(!feof($targetFile))
{
    echo "<BR>";
    echo fgets($targetFile);
    echo"*";
}



?>