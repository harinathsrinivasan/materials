<?php
$data = array(
    "name,gender,dob",
 "Harinath,Male,1990-07-13 ",
"Manoj,Male,1997-06-12",
 "Santhosh,Male,1997-10-10" ,
);

$fp = fopen('../files/person_data_out.csv', 'x');
foreach ( $data as $line ) {
$val = explode(",", $line);//split in the string based on sperator and store them in  a array
print_r($val);
fputcsv($fp, $val);
}
fclose($fp);
