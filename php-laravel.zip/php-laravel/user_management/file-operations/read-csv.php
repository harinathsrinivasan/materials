<?php

$person_data_file=fopen("../files/person_data.csv","r");
$row_num=0;//ignore the header line because header line location is 0;
while(!feof($person_data_file))
{
    if($row_num>=1)
    {
    print_r(fgetcsv($person_data_file));
    echo"<BR>";
    }
    $row_num++;
}
?>