<!DOCTYPE html>
<html>
<body>

<form action="upload_form.php" method="post" enctype="multipart/form-data">
 Select file to upload
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload Image" name="submit">
</form>


</body>
</html>