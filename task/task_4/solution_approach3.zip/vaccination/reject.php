<?php
    include("db.php");

    session_start();

    if(isset($_GET['reject'])){
        $delete =  $_GET['reject'];

        $sql = "delete from appointment where id = '$delete'";
        $result = mysqli_query($conn, $sql);
        if($result){
            header("Location:employee.php");
        }else{
            echo "error";
        }
           
    } 
?>