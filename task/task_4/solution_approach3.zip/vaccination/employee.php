<?php
    include("db.php");
    session_start();

?>
<table>
    <thead>
        <tr>
            <th>id</th>
            <th>user id</th>
            <th>pin code </th>
            <th>center name</th>
            <th>appointment date</th>
            <th>appointment time</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <?php
                $sql = "select * from appointment";
                $result = mysqli_query($conn,$sql);
                if($result){
                    $data = mysqli_fetch_assoc($result);

                    $id = $data['id'];
                    $user = $data['user_id'];
                    $pin = $data['pin_code'];
                    $center = $data['center_name'];
                    $date = $data['appointment_date'];
                    $time = $data['appointment_time'];
                    
                    echo "<tr>
                    <td>.$id.</td>
                    <td>.$user.</td>
                    <td>.$pin.</td>
                    <td>.$center.</td>
                    <td>.$date.</td>
                    <td>.$time.</td>
                    <td><button><a href='put.php?allocate={$id}'>allocate</a></button></td>
                    <td><button><a href='reject.php?reject={$id}'>reject</a></button></td>
                    </tr>";
                }
            ?>
        </tr>
    </tbody>
</table>
<button><a href="close.php">close a center</a></button>