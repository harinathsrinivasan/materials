<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .error{
            color: red;
        }
    </style>
    <title>Register</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="card bg-dark">
                    <div class="card-title bg-primary text-white mt-5">
                        <h3 class="text-center py-3">Register</h3>
                    </div>
                    <div class="card-body">
                        <form action="registered.php" method="post">
                            <div class="form-group">
                                <p class="text-white">First Name</p>
                                <input type="text" name="firstname" id="firstname" placeholder="enter your first name" class="form-control">
                            </div>
                            <div class="form-group">
                                <p class="text-white">Middle Name</p>
                                <input type="text" name="middlename" id="middlename" placeholder="enter your middle name" class="form-control">
                            </div>
                            <div class="form-group">
                                <p class="text-white">Last Name</p>
                                <input type="text" name="lastname" id="lastname" placeholder="enter your last name" class="form-control">
                            </div>
                            <div class="form-group">
                                <p class="text-white">Identification Number</p>
                                <input type="text" name="identification" id="identification" placeholder="enter your identidation number" class="form-control">
                            </div>
                            <div class="form-group">
                                <p class="text-white">Email</p> 
                                <input type="text" name="email" id="email" placeholder="enter your email" class="form-control">
                            </div>
                            <div class="form-group">
                                <p class="text-white">Mobile Number</p> 
                                <input type="text" name="mobile" id="mobile" placeholder="enter your number" class="form-control">
                            </div>
                            <div class="form-group">
                                <p class="text-white">Address</p> 
                                <textarea name="address" id="address" cols="30" rows="5"></textarea>
                            </div>
                            <div class="form-group">
                                <p class="text-white">PinCode</p> 
                                <input type="text" name="pin" id="pin" placeholder="enter your pincode" class="form-control">
                            </div>
                
                            <div class="form-group">
                                <input type="submit" value="register" class="btn bg-primary mt-3">
                                <br>
                                <a href="register.php">logout</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>	
</body>
</html>