<?php
    include("db.php");
    session_start();

    $allocate = $_SESSION['allocate'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $stocks = $_POST['stocks'];

    $sql= "update available set stocks = '$stocks' where id = '$allocate' ";
    $result = mysqli_query($conn,$sql);
    if($result){
        $sql2 = "update appointment set appointment_date='$date' , appointment_time='$time' where id ='$allocate'";
        $result2=mysqli_query($conn,$sql2);
        if ($result2){
            header("Location:employee.php");
        }
    }
?>