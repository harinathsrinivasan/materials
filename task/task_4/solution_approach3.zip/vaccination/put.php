<?php
    include("db.php");
    session_start();

    if(isset($_GET['allocate'])){
        $_SESSION['allocate'] = $_GET['allocate'];
    }
?>
<form action="put2.php" method="post">
    <select name="time" id="time">
        <option value="1">morning</option>
        <option value="2">afternoon</option>
        <option value="3">evening</option>
        <option value="4">night</option>
    </select>
    <input type="text" name="date" id="date">
    <br>
    <input type="text" name="stocks" id="stocks">
    <br>
    <input type="submit" value="submit">
</form>