<?php
    include_once("db.php");
    session_start();
    if(isset($_SESSION['user'])){
        $id = $_SESSION['user'];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <title>User Dashboard</title>
</head>
<body>
    
    <h3>User Dashboard</h3>
    <div>
        
    <!--table id="register" class="display" style="width:100%">
        <thead>
            <tr>
               <th>Id</th>
               <th></th>
            </tr>
        </thead>
        <tbody>
            
            <?php
            /*
            $sql = "select t.id,t.status,tc.name from ticket t 
            join ticket_category tc
            on t.category_id = tc.id
            where created_by = '$id'";

            $result = mysqli_query($conn,$sql);
            if($result){
                while($data=mysqli_fetch_assoc($result)){
                    $t_id = $data['id'];
                    $t_status = $data['status'];
                    $tc_name = $data['name'];
                    
                    echo "<tr>
                    <td>{$t_id}</td>
                    <td>{$t_status}</td>
                    <td>{$tc_name}</td>
                    <td>
                    <button class='btn btn-warning'><a href='new.php?view_id={$id}' class='text-white'>View</a></button>
                    </td>
                    </tr>";
                }
            }
            */
            ?>
        </tbody>
    </table-->
    <!--script>
        $(document).ready( function () {
            $('#ticket').DataTable();
        } );
    </script-->
   
    </div>
    <button class="btn btn-primary"><a href="appointment.php" class="text-white">Availability</a></button>
    <button class="btn btn-primary"><a href="appointment2.php" class="text-white">Appointment</a></button>  
    
    <button class="btn btn-danger"><a href="logout.php" class="text-white">Logout</a></button> 
</body>
</html>