<?php
    include("db.php");
    session_start();

    $_SESSION['location']= $_post['location'];

?>

<form action="appointed3.php" method="POST">
    <select name="time" id="time">
        <option value="1">morning</option>
        <option value="2">afternoon</option>
        <option value="3">evening</option>
        <option value="4">night</option>
    </select>
    <div>
    <input type="text" name="date" id="date">
    </div>
    <input type="submit" value="submit">
</form>