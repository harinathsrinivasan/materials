<?php
     $conn = mysqli_connect("localhost","root","Raghul@123","vaccination");
?>