<?php
include("db.php");
session_start();

if(isset($_GET['close'])){
    $close = $_GET['close'];

    $sql = "delete from center where center_id = '$close'";
    $result = mysqli_query($conn,$sql);
    if($result){
        header("Location:employee.php");
    }else{
        echo "error";
    }
}
?>