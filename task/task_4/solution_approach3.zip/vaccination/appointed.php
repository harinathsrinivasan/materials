<?php
    include("db.php");
    session_start();

    $center = $_POST['location'];

    $sql = "select * from available where center_id ='$center'";
    $result = mysqli_query($conn,$sql);
    if($result){
        $data = mysqli_fetch_assoc($result);
        if($data){
        $date = $data['available_date'];
        $time = $data['available_time'];
        $stock = $data['available_stocks'];
        echo $date;
    }}
?>
<table>
    <thead>
        <tr>
            <th>Date</th>
            <th>Time</th>
            <th>Stocks</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><?php echo $date;?></td>
            <td><?php echo $time;?></td>
            <td><?php echo $stock;?></td>
        </tr>
    </tbody>
</table>

<button><a href="user.php">back</a></button>