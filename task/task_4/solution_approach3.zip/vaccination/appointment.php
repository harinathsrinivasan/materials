<?php
    include("db.php");
    session_start();

    $pin = $_SESSION['pin_code'];

?>
<form action="appointed.php" method="POST">
<select name="location" id="location">
    <option value="choose">choose a center</option>
                <?php
                    $sql = "select center_id, center_name from center where pin_code = '$pin'";
                    $result = mysqli_query($conn,$sql);
                    if($result){
                        while($data = mysqli_fetch_assoc($result)){
                            $id = $data['center_id'];
                            $name = $data['center_name'];

                          echo "<option value='{$id}'>{$name}</option>";
                        }
                    }
    
                ?>   
</select>
<input type="submit" value="submit">
</form>

