<?php
    include("db.php");
    session_start();

    $user = $_SESSION['user'];
    $code = $_SESSION['pin_code'];
    $location = $_SESSION['location'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    $sql = "insert into appointment (user_id,pin_code,center,appointmet_date,appointment_time) values ('$user','$code','$location','$date','$time')";
    $result = mysqli_query($conn,$sql);
    if($reult){
        header("Location:index.php");
    }
?>