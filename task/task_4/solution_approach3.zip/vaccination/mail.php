<?php

include("db.php");
session_start();

$email = $_SESSION['email'];
$name = $_SESSION['name'];
$password = $_SESSION['password'];


    $to = $email;
    $subject = 'Password Generated';
    $message = 'Hello'.$name.', your password is generated and your password is'.$password.'';
    $headers='From: 19sc63vijay@gmail.com'."\r\n".
        'Reply-To: '.$email.''."\r\n".
        'X-Mailer: PHP/'. phpversion();

        if(mail($to,$subject,$message,$headers)){
            header("Location:mail_generated.php");
        }else{
            echo "error in mail generation";
        }
    

    

     

?>