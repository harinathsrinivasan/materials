<p>Your Password is Generated in your mail</p>

<button><a href="index.php">home</a></button>