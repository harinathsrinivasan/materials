<?php
    include("db.php");
    session_start();
    
    $id = $_POST["id"];
    $_SESSION['user']=$id;
    $password = $_POST["password"];


    $sql = "select pin_code from register where id ='$id' and password = '$password'";
    $result = mysqli_query($conn,$sql);
    if($result-> num_rows >0){
        $data = mysqli_fetch_assoc($result);
        $_SESSION['pin_code'] = $data['pin_code'];
        $pin = $_SESSION['pin_code'];
        if($pin){
            header("Location:user.php");
        }else{
            header("Location:employee.php");
        }
    }
    
?>
