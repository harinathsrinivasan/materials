<?php 

include "db.php";
session_start();

$f_name = $_POST['firstname'];
$m_name = $_POST['middlename'];
$l_name = $_POST['lastname'];
$identification = $_POST['identification'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$address = $_POST['address'];
$pincode = $_POST['pin'];
$letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
$box = array(); 
$length = strlen($letters) - 1; 
for ($i = 0; $i < 10; $i++) {
    $password = rand(0, $length);
    $box[] = $letters[$password];
}
$generated = implode($box);
$_SESSION['password'] = $generated;
$_SESSION['email']=$email;
$_SESSION['name']=$f_name;

$sql = "insert into register (first_name,middle_name,last_name,identification_no,email,phone_no,address,pin_code,password) values ('$f_name','$m_name','$l_name','$identification','$email','$mobile','$address','$pincode','$generated')";
$result = mysqli_query($conn,$sql);
if($result){
    header("Location:mail.php");
}else{
    echo "error";
}

?>