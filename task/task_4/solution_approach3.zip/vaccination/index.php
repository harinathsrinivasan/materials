<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <style>
        .error{
            color: red;
        }
    </style>
    <title>Login</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="card bg-dark">
                    <div class="card-title bg-primary text-white mt-5">
                        <h3 class="text-center py-3">Login</h3>
                    </div>
                    <div class="card-body">
                        <form action="login.php" method="post">
                           
                            <div class="form-group">
                                <p class="text-white"> id:</p>
                                <input type="text" name="id" placeholder="enter your id" class="form-control">
                                <p class="error"></p>
                            </div>
                            <div class="form-group">
                                <p class="text-white">password: </p> 
                                <input type="password" name="password" placeholder="enter your password" class="form-control">
                                <p class="error"></p>
                            </div>
                            <div class="form-group">
                                <input type="submit" value="login" class="btn bg-success mt-3">
                                <br>
                                <a href="register.php">new user? register here</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>   
</body>
</html>