<?php
    include("db.php");
    session_start();

    $sql = "select * from center";
    $result = mysqli_query($conn,$sql);
    if($result){
        $data = mysqli_fetch_assoc($result);
        $center = $data['center_id'];
        $pin = $data['pin_code'];
        $name = $data['center_name'];

        echo "<tr>
        <td>$center</td> 
        <td>$pin</td>  
        <td>$name</td>
        <td><button><a href='close2.php?close={$center}'>close</a></button></td>           
        </tr>";
    }
?>