<?php

require_once('dbconfig.php');
$error = false;

if(isset($_POST['submit'])){
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $age=$_POST['age'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $phone=$_POST['phone'];
    $activity= true;

    if (!preg_match("/^[a-zA-Z]+$/",$firstname)) {
        $firstname_error = "Name must contain only alphabets";
        }
        if (!preg_match("/^M{0,3}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$$/",$lastname)) {
            $lastname_error = "Name can contain roman numerals";
            }
            
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
        $email_error = "Please Enter Valid Email ID";
        }
        if (!preg_match("/^(\d{10}|\d{12})$/",$phone)) {
            $phone_error = "Name must contain only alphabets";
            }
            if(mysqli_query($conn, "INSERT INTO register(firstname,lastname,age,email,password,phone,activity) VALUES($firstname,$lastname,$age,$email,$password,$phone,$activity)")) {
                session_start();
                $_SESSION['email']=$email;
                $_SESSION['password']=$password;
        $to = "vijayashwin1611@gmail.com";
$subject = "Registration";
$txt = "Registration has been completed and your email is: ".$email."and password is: ".$password;
$headers = "From: vijayashwin1611@gmail.com";

if(mail($to,$subject,$txt,$headers)){
    header("location: login.php");
    exit();    
}
else{
    echo "Failed";
}
                } else {
                    $error = "Something went wrong";
                echo $error ;
                }
                mysqli_close($conn);
                }
                

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <title>Document</title>
    <style>
        .container{
            border: 3x solid black;
        }
    </style>
</head>
<body>
    <div class="container">
    <form method="POST" action=<?php print $_SERVER['PHP_SELF'];?>>
    <div class="form-group">
        <label for="firstname"> First name </label><br>
        <input type="text" name="firstname" class="form-control-sm" required>
        <span class="text-danger"><?php if (isset($firstname_error)) echo $firstname_error; ?></span>
    </div>
    <div class="form-group">
        <label for="lastname"> Last name </label><br>
        <input type="text" name="lastname" class="form-control-sm" required>
        <span class="text-danger"><?php if (isset($lastname_error)) echo $lastname_error; ?></span>
    </div>
    <div class="form-group">
    <label> Age </label><br>
        <input type="text" name="age"  class="form-control-sm"  required>
        <span class="text-danger"><?php if (isset($age_error)) echo $age_error; ?></span>
        </div>
        <div class="form-group">
        <label> Email </label><br>
        <input type="email" name="email"  class="form-control-sm"  required>
        <span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
        </div>
        <div class="form-group">
        <label> Password </label><br>
        <input type="password" name="password"  class="form-control-sm"  required>
        <span class="text-danger"><?php if (isset($password_error)) echo $password_error; ?></span>
        </div>
        <div class="form-group">
        <label> Phone </label><br>
        <input type="number" name="phone"  class="form-control-sm"  required>
        <span class="text-danger"><?php if (isset($phone_error)) echo $phone_error; ?></span>
        <br><br>
        <div class="form-group">
        <input type="submit" name="submit"  class="form-control-sm"  value="Submit">
        <span style='color:red'><?php echo $error; ?></span>
        </div>
    </form>
    </div>
</body>
</html>