
create table register(id serial primary key,firstname VARCHAR(75),
lastname VARCHAR(75),
age int,
email VARCHAR(75) PRIMARY KEY,
phone BIGINT UNSIGNED
password VARCHAR(75),activity VARCHAR(25)
);                     

create table login(email VARCHAR(75) PRIMARY KEY, password VARCHAR(75));

create table appointment(id serial PRIMARY KEY,consult VARCHAR(255), 
language VARCHAR(255),status enum(pending,approved,closed),
aptdate date);

//Search appointment by ID
select id, consult, language, status, aptdate from appointment where id=?

//Update an appointment
UPDATE appointment SET status = '$status' WHERE id = '$id'

//Disabled a patient using activity
select id, firstname, lastname, age, email, phone, password from register where activity=false;
