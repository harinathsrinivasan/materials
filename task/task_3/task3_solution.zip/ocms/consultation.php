<?php

if(isset($_POST['submit'])){
    session_start();
    $email = $_SESSION['email'];
    $consult =$_POST['consult'];
    $language =$_POST['language'];
    $consult =$_POST['date'];
    if(mysqli_query($conn, "INSERT INTO appointment(consult,language,date) VALUES($consult,$language,$date)")) {

    $date = $_POST['date'];
    $_SESSION['date'] = $date;
    $to = "vijayashwin1611@gmail.com";
    $subject = "Appointment confirmation";
    $txt = "Appointment has been fixed on: ".$date;
    $headers = "From: vijayashwin1611@gmail.com";
    
    if(mail($to,$subject,$txt,$headers)){
        header("location: appointments.php");
        exit();    
    }
    else{
        echo "Failed";
    }
}
}
?>
<div class="topnav">
<a class="active" href="#home">Home</a>
  <a href="appointments.php">Appointments</a>
</div>
<div class="container">
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
<div>
<label for="consult">Choose Consultation as per your need:</label>
    <select name="consult" >
        <option selected value="1">General Consultation</option>
        <option value="2">Speciality Consultation</option>
     </select>

</div>

<div>

    <label for="language">Choose your comfortable language to communicate:</label>
    <select name="language" multiple required>
        <option selected value="1">English</option>
        <option value="2">Tamizh</option>
        <option value="3">Telugu</option>
        <option value="4">Hindi</option>
        <option value="5">Malayalam</option>
     </select>
</div>
<div>
     <label>Choose the comfortable date for an appointment:</label>
      <input type="date" name="date">  
</div>

<div>
    <input type="submit" name="submit" value="Submit">
</div>
</form>
</div>