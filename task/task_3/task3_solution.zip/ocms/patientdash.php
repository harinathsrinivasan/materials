<div class="topnav">
  <a class="active" href="#home">Home</a>
  <a href="upload.php">Medical record upload</a>
  <a href="consultation.php">Online consultation</a>
  <a href="#appointments.php">Upcoming Appointments</a>
</div>

<h1>
  Welcome to OCMS!!
  Choose your requirement on the above links
</h1>


