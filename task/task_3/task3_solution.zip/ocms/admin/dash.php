<?php
require_once("repo.php");
$appointments=get_patients_appointment();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <title>Manager Dashboard</title>
    <link rel="stylesheet" href="mgrdash.css">
    <script>
    $(document).ready(function() {
      var trigger = $('.hamburger'),
        overlay = $('.overlay'),
        isClosed = false;

      trigger.click(function() {
        hamburger_cross();
      });

      function hamburger_cross() {

        if (isClosed == true) {
          overlay.hide();
          trigger.removeClass('is-open');
          trigger.addClass('is-closed');
          isClosed = false;
        } else {
          overlay.show();
          trigger.removeClass('is-closed');
          trigger.addClass('is-open');
          isClosed = true;
        }
      }

      $('[data-toggle="offcanvas"]').click(function() {
        $('#wrapper').toggleClass('toggled');
      });
    });
  </script>
</head>

<body>
<nav class="navbar navbar-expand navbar-dark" style="background-color: dodgerblue;"> <a href="#menu-toggle" id="menu-toggle" class="navbar-brand"><span class="navbar-toggler-icon"></span></a>


  <form class="form-inline my-2 my-md-0"> </form>
  </div>
</nav>

<div id="wrapper">
  <div class="overlay"></div>

  <!-- Sidebar -->
  <nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation">
    <ul class="nav sidebar-nav">
      <li class="sidebar-brand">
        <a href="#">
          Dashboard
        </a>
      </li>
      <li>
        <a href="dash.php">Home</a>
      </li>
      <li>
        <a href="patientdetails.php">Patient details</a>
      </li>
      <li>
        <a href="searchbyappointmentid.php">Search</a>
      </li>
      <li>
      <a href="activepatients.php">Active patients</a>
      </li>
      <li>
        <a href="../login.php">Log out</a>
      </li>

    </ul>
  </nav>
<!-- /#sidebar-wrapper -->

  <!-- Page Content -->
  <div id="page-content-wrapper">
    <button type="button" class="hamburger is-closed" style="margin-top:-9px;" data-toggle="offcanvas">
      <span class="hamb-top"></span>
      <span class="hamb-middle"></span>
      <span class="hamb-bottom"></span>
    </button>

<table class="table table-bordered table-hover">
<thead>
    <th>Appointment id</th>
    <th>Consultation type</th>
    <th>Familiar Language</th>
    <th>Appointment Date</th>
    <th>Allocation</th>
    <th>Rejection</th>
</thead>
<tbody>
    <?php foreach($appointment as $appointments)
    {
        ?>
        <tr>
            <td><?php echo $appointment["id"];?></td>
            <td><?php echo $appointment["consult"]; ?></td>
            <td><?php echo $appointment["language"];?></td>
            <td><?php echo $appointment["aptdate"];?></td>
            
            <td><button class="btn btn-primary"><a style="color:white" href="approval.php?id= <?php echo $appointment['id'];?>" >Approval</a></td></button>
            <td><button class="btn btn-danger"><a style="color:white" href="reject.php?id= <?php echo $appointment['id'];?>" >Reject</a></td></button>
        </tr>
    <?php }?>
    
</tbody>
</table>
</body>

</html>

<?php
  include('D:\seed56\xampp\htdocs\EMS\footer.php');

  ?>
