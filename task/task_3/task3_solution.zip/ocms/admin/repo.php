<?php 
require_once("dbconfig.php");
//get appointment details
function get_patients_appointment()
{
    $return_var=array();
  
    $connection=get_db_connection();
    $pstmt_get_patients_appointment=mysqli_prepare($connection,
    "   SELECT id,consult,language,date
    FROM appointments");
    mysqli_stmt_bind_result($pstmt_get_patients_appointment,$id,$consult,$language,$date);
    mysqli_stmt_execute($pstmt_get_patients_appointment);
    $result_set=mysqli_stmt_get_result($pstmt_get_patients_appointment);
    $return_var=mysqli_fetch_all($result_set,MYSQLI_ASSOC); 
    return $return_var;
}

function get_patients_detail(){
    $return_var=array();
  
    $connection=get_db_connection();
    $pstmt_get_patients_detail=mysqli_prepare($connection,
    "   SELECT id,firstname,lastname,age,email,phone,password
    FROM register");
    mysqli_stmt_bind_result($pstmt_get_patients_detail,$id,$firstname,$lastname,$age,$email,$phone,$password);
    mysqli_stmt_execute($pstmt_get_patients_detail);
    $result_set=mysqli_stmt_get_result($pstmt_get_patients_detail);
    $return_var=mysqli_fetch_all($result_set,MYSQLI_ASSOC); 
    return $return_var;
}

function get_appointment_by_id($id)
{
$appointment=null;
require_once (dbconfig.php);
    $pstmt_get_appointment_by_id=mysqli_prepare($connection,
    "SELECT consult,  language ,status, aptdate FROM `appointment` 
    WHERE id=?");
    mysqli_stmt_bind_param( $pstmt_get_appointment_by_id,"i",$id);
    mysqli_stmt_bind_result($pstmt_get_appointment_by_id,$consult,$language,$status,$aptdate);
    mysqli_stmt_execute($pstmt_get_appointment_by_id);
    $result_set=mysqli_stmt_get_result($pstmt_get_appointment_by_id);
    $appointment=mysqli_fetch_all($result_set,MYSQLI_ASSOC);
    return $appointment;

}

?>