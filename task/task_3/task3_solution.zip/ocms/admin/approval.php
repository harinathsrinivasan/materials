<?php

use phpDocumentor\Reflection\Location;

include ("dbconfig.php");
    session_start();

    if(isset($_POST['id'])){
      $id =  $_POST['id'];
    $status = $_POST['status'];
    
    $sql ="UPDATE appointment SET status = '$status' WHERE id = '$id'";
    print $sql;
         $con=mysqli_connect("localhost","root","password","ocms");
    $result = mysqli_query($con,$sql);
    print mysqli_error($con);
    if($result){
       header("Location:dash.php");
    }else{
       echo "Updation failed";
    }
   }
?>