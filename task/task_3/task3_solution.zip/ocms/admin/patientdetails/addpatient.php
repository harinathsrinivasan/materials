<?php

use phpDocumentor\Reflection\Location;

header("Location:register.php");

?>