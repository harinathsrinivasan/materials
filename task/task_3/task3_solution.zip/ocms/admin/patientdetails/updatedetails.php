<?php

use phpDocumentor\Reflection\Location;

include ("dbconfig.php");
    session_start();

    if(isset($_POST['id'])){
      $id =  $_POST['id'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $age = $_POST['age'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    $sql ="UPDATE register SET firstname = '$firstname', lastname = '$lastname', age = '$age'
    ,email = '$email', password = 'password', phone ='$phone'
      WHERE id = '$id'";
    print $sql;
         $con=mysqli_connect("localhost","root","password","ocms");
    $result = mysqli_query($con,$sql);
    print mysqli_error($con);
    if($result){
       header("Location:dash.php");
    }else{
       echo "Updation failed";
    }
   }
?>