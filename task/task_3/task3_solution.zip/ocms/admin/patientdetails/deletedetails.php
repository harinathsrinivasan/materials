<?php

include("dbconfig.php");

    session_start();

    if(isset($_GET['id'])){
        $id =  $_GET['id'];

        $sql = "TRUNCATE FROM  register WHERE id = '$id';";
        $con=mysqli_connect("localhost","root","password","ocms");
        $result = mysqli_query($con, $sql);
        if($result){
           header("Location:dash.php");
        }else{
            echo "error";
        }
       
    }
?>