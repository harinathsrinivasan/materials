<?php
require_once("repo.php");
$patients_detail=get_appointment_by_id($_GET('id'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <title>Manager Dashboard</title>
    <link rel="stylesheet" href="mgrdash.css">
    <script>
    $(document).ready(function() {
      var trigger = $('.hamburger'),
        overlay = $('.overlay'),
        isClosed = false;

      trigger.click(function() {
        hamburger_cross();
      });

      function hamburger_cross() {

        if (isClosed == true) {
          overlay.hide();
          trigger.removeClass('is-open');
          trigger.addClass('is-closed');
          isClosed = false;
        } else {
          overlay.show();
          trigger.removeClass('is-closed');
          trigger.addClass('is-open');
          isClosed = true;
        }
      }

      $('[data-toggle="offcanvas"]').click(function() {
        $('#wrapper').toggleClass('toggled');
      });
    });
  </script>
</head>

<body>
<nav class="navbar navbar-expand navbar-dark" style="background-color: dodgerblue;"> <a href="#menu-toggle" id="menu-toggle" class="navbar-brand"><span class="navbar-toggler-icon"></span></a>


  <form class="form-inline my-2 my-md-0"> </form>
  </div>
</nav>

<div id="wrapper">
  <div class="overlay"></div>

  <!-- Sidebar -->
  <nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation">
    <ul class="nav sidebar-nav">
      <li class="sidebar-brand">
        <a href="#">
          Dashboard
        </a>
      </li>
      <li>
        <a href="dash.php">Home</a>
      </li>
      <li>
        <a href="patientdetails.php">Patient details</a>
      </li>
      <li>
        <a href="addpatient.php">Add new patient</a>
      </li>
      <li>
        <a href="searchbyappointmentid.php">Search</a>
      </li>
      <li>
        <a href="../login.php">Log out</a>
      </li>

    </ul>
  </nav>
<!-- /#sidebar-wrapper -->

  <!-- Page Content -->
  <div id="page-content-wrapper">
    <button type="button" class="hamburger is-closed" style="margin-top:-9px;" data-toggle="offcanvas">
      <span class="hamb-top"></span>
      <span class="hamb-middle"></span>
      <span class="hamb-bottom"></span>
    </button>

<table class="table table-bordered table-hover">
<thead>
    <th>id</th>
    <th>First name</th>
    <th>Last name</th>
    <th>Age</th>
    <th>Email</th>
    <th>Password</th>
    <th>Phone</th>
    <th>Edit</th>
    <th>Delete</th>

</thead>
<tbody>
    <?php foreach($patient as $patients_detail)
    {
        ?>
        <tr>
            <td><?php echo $patient["id"];?></td>
            <td><?php echo $patient["firstname"]; ?></td>
            <td><?php echo $patient["lastname"];?></td>
            <td><?php echo $patient["age"];?></td>
            <td><?php echo $patient["email"];?></td>
            <td><?php echo $patient["password"];?></td>
            <td><?php echo $patient["phone"];?></td>
    
        </tr>
    <?php }?>
    
</tbody>
</table>
</body>

</html>

<?php
  include('D:\seed56\xampp\htdocs\EMS\footer.php');

  ?>
