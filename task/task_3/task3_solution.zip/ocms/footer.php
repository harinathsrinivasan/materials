<head>
    <style>
.footer {
   position: absolute;
   left: 0;
   bottom: -08vh;
   width: 100%;
   background-color: #f1f1f1;
   color: black;
   text-align: center;
}
body { padding-bottom: 20vh; }
</style>
</head>
<body>
<div class="navbar fixed-bottom">
<div class="footer">
  <p> © Copyright 2021 STM project</p>
</div>
</div>
</body>