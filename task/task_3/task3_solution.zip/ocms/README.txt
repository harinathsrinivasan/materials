/*
*OCMS - The application domain name*

*ocms.sql - Contains the domain queries*

*To register the patient details*  --> register.php 

Sub Requirements 
- Login details Mail sent for the registered user
- Validation for each field has been done

*Patient can login using email & password throuh*  --> login.php
On successful login redirection to patientdash.php
Using Medical record upload link, patient can upload existing medical record.

*Then online consultation link, for creating an appointment*
Patient can choose Multiple language

-Appointment.php for the scheduled appointment details

-Admin can approve, reject, search an appointment

-Admin can add, update, delete the patient details

-disabled patients are hidden in the activepatients.php

-repo.php for the functions definition





*/