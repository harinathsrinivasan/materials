<?php
session_start();
$error = false;
require_once (dbconfig.php);
if (isset($_POST['login'])) {
    $email =$_POST['email'];
    $password = $_POST['password'];
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
    $email_error = "Please Enter Valid Email ID";
    }
    $result = mysqli_query($conn, "SELECT email,password FROM login WHERE email =$email and password =$password");
if(!empty($result)){
header("Location: patientdash.php");
}
else{
    $error = "Error occurred";
 echo $error;
}

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login</title>
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="container">
<div class="row">
<div class="col-lg-10">
<div class="page-header">
<h2>Login Form</h2>
</div>
<p>Please fill all fields in the form</p>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
<div class="form-group ">
<label>Email</label>
<input type="email" name="email" class="form-control"   required>
<span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
</div>
<div class="form-group">
<label>Password</label>
<input type="password" name="password" class="form-control"  required>
<span class="text-danger"><?php if (isset($password_error)) echo $password_error; ?></span>
</div>  
<input type="submit" class="btn btn-primary" name="login" value="submit">
<br>
You don't have account?<a href="register.php" class="mt-3">Click Here</a>
</form>
</div>
</div>     
</div>
</body>
</html>
