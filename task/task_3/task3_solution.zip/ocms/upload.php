<form action="" method = "post" enctype="multipart/form-data">

<label for="record">Existing Medical record </label>
          <input type="file" id="record" name="record" required><br>
          <button class="submit" type="submit" name="submit"><b>Upload</b></button>
        </form>