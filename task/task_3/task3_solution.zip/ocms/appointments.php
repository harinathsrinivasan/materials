<div>
    <Label>Your appointment has been fixed as per the schedule</Label>
    <input type="text" value="<?php print $SESSION['date'];?>"readonly>
</div>