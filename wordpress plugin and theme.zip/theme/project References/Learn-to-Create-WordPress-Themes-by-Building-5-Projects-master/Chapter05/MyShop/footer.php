    <footer>
    <p>&copy; 2017, MyShop</p>
    </footer>
	
	<?php wp_footer(); ?>

    <script src="js/vendor/jquery.js"></script>
    <script src="js/vendor/what-input.js"></script>
    <script src="js/vendor/foundation.js"></script>
    <script src="js/app.js"></script>
  </body>
</html>
