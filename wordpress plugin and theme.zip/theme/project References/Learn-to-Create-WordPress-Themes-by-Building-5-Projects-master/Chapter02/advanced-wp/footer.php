	<footer class="main-footer">
	<div class="container">
	<div class="f_left">
		<p>&copy; 2017 - Advanced WP Theme</p>
	</div>
	<div class="f_right">
		<ul>
			<li><a href="index.html">Home</a></li>
			<li><a href="about.html">About</a></li>
			<li><a href="#">Services</a></li>
		</ul>
	</div>
	</div>
	</footer>
	<?php wp_footer(); ?>
</body>
</html>